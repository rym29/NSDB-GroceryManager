const { Timestamp } = require("mongodb");
const { default: mongoose } = require("mongoose");


const CartSchema = new mongoose.Schema({
    ProdId:{type:String,required:true,unique:true},
    ProdDesc:{type:String},
    ProdPrice:{type:Number},
    dateOfDelivery:{type:String},
    useremail:{type:String,required:true}
})


const CartModel = mongoose.model('CartData',CartSchema);


module.exports = CartModel;