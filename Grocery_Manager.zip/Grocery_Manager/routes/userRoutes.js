const {Router,request,response} = require('express');
const {registerController, loginController} = require('../controller/userController');

const userRoutes = Router();

// userRoutes.post('/login',loginController(request,response));

userRoutes.post('/register',registerController(request,response));


module.exports = userRoutes; 