const {Router,request,response} =  require('express');
const {createController,updateController,deleteController} = require('../controller/CartController');

const CartRouter = Router();

//CartRouter.get('/getallCart');
CartRouter.post('/createCart',(request,response)=>{createController(request,response)});
CartRouter.put('/updateCart',(request,response)=>{updateController(request,response)});
CartRouter.delete('/deleteCart',(request,response)=>{deleteController(request,response)});

// CartRouter.put('/updateCart',updateController(request,response));
// CartRouter.delete('/deleteCart',deleteController(request,response));

module.exports = CartRouter;

