const CartModel = require("../models/CartModel");
//create
const createController= async(request,response)=>{
    const{ProdId,ProdPrice,dateOfDelivery,ProdDesc,useremail}=request.body;
    try{
        const CartResponse=await CartModel.create({
            ProdId:ProdId,
            ProdPrice:ProdPrice,
            dateOfDelivery:dateOfDelivery,
            ProdDesc:ProdDesc,
            useremail:useremail
        })
        if(CartResponse&&CartResponse._id){
            response.status(201).json({message:"Item added to cart successfully"});
        }
        else{
            response.status(404).json({message:"Item not created"});
        }
    }
    catch(error){
        response.status(500).json({message:"Network error"});
    }
}
//update
const updateController= async(request,response)=>{
    const{ProdId,ProdPrice,dateOfDelivery,ProdDesc,useremail}=request.body;
    try{
        const CartResponse=await CartModel.updateOne({
            ProdId:ProdId
        })
        response.status(201).json({message:"Cart updated successfully"});

    }catch(error){
        response.status(500).json({message:"Network error"});
    }
}
//delete
const deleteController=async(request,response)=>{
    const{ProdId}=request.body;
    try{
        const CartResponse=await CartModel.deleteOne(
        {
            ProdId:ProdId
        })
        response.status(201).json({message:"Cart item deleted successfully"});
    }catch(error){
        response.status(500).json({message:"Network error"});
    }
}
module.exports = {createController,updateController,deleteController}