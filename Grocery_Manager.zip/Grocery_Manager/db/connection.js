const  mongoose  = require("mongoose")

const URL = "mongodb+srv://admin:Vijay3366@cluster0.np7jsfw.mongodb.net/groceryShop?retryWrites=true&w=majority";
const connection = ()=>{
    mongoose.connect(URL).then(()=>{
        console.log("Database Connected Successfully");
    }).catch(()=>{
        console.log("Database Not Connected");
    })
}

module.exports = connection;